# SecondLife image validation test kit

Extract this ZIP. Read SWAGGER_LISTING_IMAGE_VALIDATION_TEST.md, restart the updated BE, and select files from listing-images. The kit contains 40 synthetic technical fixtures; use mode=manual. Authentication/category IDs must come from your test environment. This ZIP does not call any API or modify a database.
