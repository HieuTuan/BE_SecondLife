# FE web/mobile: ảnh đăng bán và lỗi validation

## Contract giữ nguyên

`POST /api/v1/posts/init`, Bearer token có `LISTING_CREATE_SELF`, `multipart/form-data`: `categoryId`, tùy chọn `itemId/brand/model`, `mode=manual|ai`, nhiều part tên `images`. Không gửi base64 hoặc URL thay cho file. Không tự set header Content-Type của toàn request khi dùng browser FormData; trình duyệt cần tự thêm boundary.

BE hiện kiểm tra **3–6 ảnh**, <=**10 MiB/ảnh**, cạnh ngắn >=**600 px**, <=**16.000 px/cạnh**, <=**25.000.000 pixel** (các ngưỡng có cấu hình). FE đang có logic cho tiếp tục từ 1 ảnh cần sửa về 3; không chỉ sửa dòng chữ hướng dẫn.

## Trước khi gửi

1. Kiểm tra số lượng, file rỗng, định dạng, dung lượng và khả năng đọc. `accept` chỉ là gợi ý file picker.
2. Đọc hướng xoay EXIF và xoay đúng **một lần**. Nếu đã xoay pixel thì bỏ/reset orientation để không bị BE xoay lại.
3. Resize giữ tỷ lệ, ưu tiên cạnh dài 2560 px, không upscale để vượt ngưỡng. Không ép ảnh thành hình vuông hoặc cắt mất nhãn/serial.
4. Có thể nén JPEG quality khoảng 0.9; dung lượng cuối vẫn phải đo lại. Không hứa mọi ảnh sẽ nhỏ hơn một giá trị chỉ nhờ quality cố định.
5. HEIC từ mobile: chuyển đổi thật sang JPEG trên thiết bị hoặc dùng bộ chuyển đổi được hỗ trợ. Nếu client không chuyển được thì báo chọn ảnh JPEG/PNG/WebP. Không đổi tên đuôi.
6. Hiển thị preview, xóa/thay từng ảnh; giữ đúng thứ tự và ảnh đầu làm ảnh đại diện. Không tự bỏ ảnh lỗi rồi gửi ít hơn 3 ảnh.
7. Một ảnh nhiều tên/metadata vẫn có thể bị BE coi trùng. Yêu cầu thêm góc chụp thật, không khuyên chỉnh byte để vượt kiểm tra.
8. Khi tạo lại `Blob`/`File`, đặt đúng tên và MIME cho bytes đã encode: JPEG → `.jpg` + `image/jpeg`, PNG → `.png` + `image/png`, WebP → `.webp` + `image/webp`. Không đặt mọi Blob thành `image.jpg` khi bytes vẫn là PNG/WebP.

BE xác thực lại file, áp hướng xoay EXIF và reencode không mang metadata nguồn. Ảnh đầu ra có thể là JPEG/PNG, dù input WebP. FE dùng URL và định dạng server trả, không tự dựng đuôi URL.

## Hiển thị lỗi

- HTTP **400**: đọc `errors[]`; `images[1]` gắn với ảnh thứ hai trong đúng danh sách đã gửi. Có thể có nhiều ảnh lỗi.
- HTTP **413**: quá dung lượng từng file/tổng request; lỗi có thể ở `images` thay vì index do servlet chặn trước.
- HTTP **503**: đang hết slot xử lý ảnh; giữ nguyên file và cho thử lại sau, không đánh dấu ảnh là hỏng. Không tự gọi dồn dập.
- **401/403**: xử lý đăng nhập/quyền; không biến thành thông báo sai định dạng ảnh.
- File lỗi vẫn phải ở lại form để thay/xóa; không mất danh mục, brand, model và những ảnh hợp lệ khác.
- Nút gửi phải disable khi đang xử lý/upload, hiển thị tiến trình hoặc trạng thái chờ và bật lại khi lỗi.
- Giữ snapshot danh sách đã gửi để gắn lỗi đúng ảnh; có thể khóa thêm/xóa/đổi thứ tự ảnh trong lúc request đang chạy.
- Không dựa vào việc parse câu chữ lỗi để xác định index: dùng `errors[].field`.

```json
{
  "success": false,
  "message": "Ảnh tải lên chưa hợp lệ",
  "path": "/api/v1/posts/init",
  "errors": [
    {"field": "images[1]", "message": "Ảnh có kích thước 800 × 599 px. Cạnh ngắn phải đạt ít nhất 600 px."}
  ],
  "timestamp": "2026-10-28T12:00:00"
}
```

## Lưu ý tích hợp

- Đây là thay đổi BE và hướng dẫn cho cả web/native; code FE chưa được sửa trong lần này.
- Client nên gửi MIME đúng. Trường hợp không có MIME hoặc `application/octet-stream` được BE xử lý theo bytes/đuôi/decoder; MIME cụ thể nhưng giả vẫn bị chặn.
- API media dùng cùng kiểm tra file an toàn nhưng không áp 3–6 ảnh hoặc 600 px tối thiểu của listing, để không làm hỏng avatar/KYC.
- API media multiple còn giới hạn tổng bytes **sau chuẩn hóa** theo `spring.servlet.multipart.max-request-size` (hiện 64 MiB), vì một batch WebP/PNG nén nhỏ có thể nở lớn khi chuyển đổi. Vượt ngưỡng trả 413 ở field `files`, chưa upload file nào.
- Cấu hình `spring.servlet.multipart.max-request-size` phải hữu hạn và dương; không dùng `-1` cho batch ảnh.
- Mode manual vẫn bị toàn bộ validation kỹ thuật; phần AI kiểm tra đúng loại/hãng vẫn theo luồng AI hiện có.
- Ảnh mờ/tối/không thấy sản phẩm là chất lượng/nghiệp vụ, không đồng nhất với file hỏng; chưa thêm ngưỡng AI chặn mới trong thay đổi này.
- Không áp chính sách bỏ metadata/recompress của listing lên bằng chứng tranh chấp một cách tự động: bằng chứng có yêu cầu lưu giữ riêng.
- Cấu hình mới tùy chọn: `LISTING_IMAGE_MIN_SHORT_SIDE=600`, `LISTING_IMAGE_NORMALIZED_MAX_SIDE=2560`. Các giới hạn số lượng/byte/pixel tiếp tục dùng cấu hình hiện hữu. Không có API đọc policy mới; cấu hình UI và BE cần được đồng bộ khi đổi ngưỡng.
- Xem bộ test và JSON: [SWAGGER_LISTING_IMAGE_VALIDATION_TEST.md](SWAGGER_LISTING_IMAGE_VALIDATION_TEST.md).
